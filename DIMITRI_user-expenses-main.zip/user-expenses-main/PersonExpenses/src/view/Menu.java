package view;

public class Menu {
	
	public static void mainMenu() {
		// TODO Auto-generated method stub

		System.out.println("\nEnter your choice:");
		System.out.println("1 - To create a new user account / SingUp");
		System.out.println("2 - To logIn");
		System.out.println("3 - To edit/update an existing user account:");
		System.out.println("0 - To quit\n");
		
	}

}
