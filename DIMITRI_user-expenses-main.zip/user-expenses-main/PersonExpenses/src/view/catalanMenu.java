package view;

public class catalanMenu {

}
