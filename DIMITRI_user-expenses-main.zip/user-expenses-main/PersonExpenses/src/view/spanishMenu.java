package view;

public class spanishMenu {

}
